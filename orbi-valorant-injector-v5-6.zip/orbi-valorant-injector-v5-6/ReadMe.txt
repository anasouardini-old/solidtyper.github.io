"orbi-valorant-injector-v5-6" is an extractor that extract dll and config files of the hack and adds them to valorant folder.

you don't need to copy past them any more this will automatically do that for you.